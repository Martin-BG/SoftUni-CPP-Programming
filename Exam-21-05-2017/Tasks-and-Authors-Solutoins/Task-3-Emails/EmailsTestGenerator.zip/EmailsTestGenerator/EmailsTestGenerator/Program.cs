﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmailsTestGenerator
{
    class Program
    {
        static Random rand = new Random();

        static void Main(string[] args)
        {
            GenerateTest("test.001", "abc", 5, 2, 3);
            GenerateTest("test.002", "second", 10, 3, 2);
            GenerateTest("test.003", "thiiiiiird", 50, 10, 20);
            GenerateTest("test.004", "fourth", 50, 20, 10);
            GenerateTest("test.005", "fifth", 100, 50, 50);

            GenerateTest("test.006", "bigone", 1000, 2, 3);
            GenerateTest("test.007", "bigtwo", 2500, 20, 50);
            GenerateTest("test.008", "bigthree", 2500, 100, 20);
            GenerateTest("test.009", "bigfour", 2500, 20, 50, true);
            GenerateTest("test.010", "bigfive", 2500, 100, 90, true);
        }

        static void GenerateTest(string testName, string searchWord, int messagesCount, int pageSize, int hits, bool maxWords = false)
        {
            List<List<string>> messages = new List<List<string>>();
            List<List<string>> topMessages = new List<List<string>>();

            for (int i = 0; i < messagesCount; i++)
            {
                List<string> message = new List<string>();
                if (i < hits)
                {
                    for (int j = 0; j < i + 1; j++)
                    {
                        message.Add(searchWord);
                    }

                    topMessages.Add(message);
                    if (topMessages.Count > pageSize)
                    {
                        topMessages.RemoveAt(0);
                    }
                }

                messages.Add(message);
            }

            for (int i = 0; i < messages.Count; i++)
            {
                List<string> message = messages[i];
                int messageWords = maxWords ? 100 : rand.Next(message.Count + 1, 95);
                while (message.Count < messageWords)
                {
                    var w = GetRandomWord(maxWords ? 10 : 0);
                    while (w.Equals(searchWord))
                    {
                        w = GetRandomWord();
                    }

                    message.Add(w);
                }

                Shuffle(message);
            }

            Shuffle(messages);

            StringBuilder inputBuilder = new StringBuilder();
            inputBuilder.AppendLine(searchWord);
            inputBuilder.AppendLine(pageSize + "");

            foreach (var message in messages)
            {
                inputBuilder.AppendLine(string.Join(" ", message));
            }

            inputBuilder.AppendLine(".");

            StringBuilder outputBuilder = new StringBuilder();

            for (int i = topMessages.Count - 1; i >= 0; i--)
            {
                outputBuilder.AppendLine(string.Join(" ", topMessages[i]));
            }

            System.IO.File.WriteAllText(testName + ".in.txt", inputBuilder.ToString());
            System.IO.File.WriteAllText(testName + ".out.txt", outputBuilder.ToString());
        }


        static string wordCharacters = null;

        static string GetRandomWord(int length = 0)
        {
            if (wordCharacters == null)
            {
                StringBuilder characters = new StringBuilder();
                for (char c = 'a'; c <= 'z'; c++)
                {
                    characters.Append(c);
                }

                wordCharacters = characters.ToString();
            }

            length = length == 0 ? rand.Next(1, 10 + 1) : length;
            StringBuilder word = new StringBuilder();
            for (int i = 0; i < length; i++)
            {
                word.Append(wordCharacters[rand.Next(0, wordCharacters.Length)]);
            }

            return word.ToString();
        }

        static void Shuffle<T>(List<T> list)
        {
            for (int repeats = 0; repeats < 10; repeats++)
            {
                for (int i = 0; i < list.Count; i++)
                {
                    int otherInd = rand.Next(0, list.Count);
                    var swap = list[i];
                    list[i] = list[otherInd];
                    list[otherInd] = swap;
                }
            }
        }
    }
}
