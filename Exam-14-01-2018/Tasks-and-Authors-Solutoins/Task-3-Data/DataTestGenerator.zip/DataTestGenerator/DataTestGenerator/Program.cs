﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataTestGenerator
{
    class Program
    {
        static Random rand = new Random();

        static void Main(string[] args)
        {
            GenerateTest("test.001", 10, 3, 5, 2, "music", "age", "happiness", "creativity");
            GenerateTest("test.002", 3, 10, 5, 2, "hometown", "business", "age", "significantother", "job", "position", "planet", "galaxy");
            GenerateTest("test.003", 20, 30, 15, 12, "weight", "height", "bmi", "haircolor", "age", "bonemass", "fatpercentage", "bloodtype", "eyecolor");
            GenerateTest("test.004", 10, 1, 2, 0, "music", "age", "happiness", "fatpercentage", "bloodtype", "eyecolor");
            GenerateTest("test.005", 3, 30, 15, 14, "hometown", "business", "age", "significantother", "job", "happiness", "creativity");

            GenerateTest("test.006", 100, 3, 5, 2, "music", "age", "happiness", "creativity");
            GenerateTest("test.007", 3, 100, 5, 2, "hometown", "business", "age", "significantother", "job", "position", "planet", "galaxy");
            GenerateTest("test.008", 200, 300, 150, 120, "weight", "height", "bmi", "haircolor", "age", "bonemass", "fatpercentage", "bloodtype", "eyecolor");
            GenerateTest("test.009", 100, 1, 2, 0, "music", "age", "happiness", "fatpercentage", "bloodtype", "eyecolor");
            GenerateTest("test.010", 300, 30, 150, 140, "hometown", "business", "age", "significantother", "job", "happiness", "creativity");
        }

        static void GenerateTest(string testName, int objectsCount, int valuesPerPropertyCount, int positiveQueriesCount, int negativeQueriesCount, params string[] possibleProperties)
        {
            List<Dictionary<string, string>> objects = new List<Dictionary<string, string>>();

            string index = possibleProperties[rand.NextIndex(possibleProperties)];

            Dictionary<string, List<string>> propertyValues = new Dictionary<string, List<string>>();
            foreach (var prop in possibleProperties)
            {
                List<string> values = new List<string>();
                for (int i = 0; i < valuesPerPropertyCount; i++)
                {
                    values.Add(rand.NextWordOrNumber(10));
                }

                propertyValues[prop] = values;
            }

            HashSet<string> usedIndexValues = new HashSet<string>();

            while (objects.Count < objectsCount)
            {
                Dictionary<string, string> o = new Dictionary<string, string>();
                foreach (var prop in possibleProperties)
                {
                    if (rand.NextChance(prop == index ? 0.9 : 0.6))
                    {
                        string v = rand.NextItem(propertyValues[prop]);
                        o[prop] = v;
                        if (prop == index)
                        {
                            usedIndexValues.Add(v);
                        }
                    }
                }

                objects.Add(o);
            }

            List<string> queries = new List<string>();
            List<string> queryResults = new List<string>();

            List<string> usedIndexValuesList = usedIndexValues.ToList();

            for (int i = 0; i < positiveQueriesCount + negativeQueriesCount; i++)
            {
                if (i % 2 == 0)
                {
                    // positive
                    string indexValue = rand.NextItem(usedIndexValuesList);
                    string propName = rand.NextItem(possibleProperties);

                    IEnumerable<string> resultPropValues = objects
                        .Where(o => o.ContainsKey(index) && o[index] == indexValue && o.ContainsKey(propName))
                        .Select(o => o[propName]);
                    string queryResult = string.Join(" ", resultPropValues);

                    queries.Add(indexValue + " " + propName);
                    queryResults.Add(queryResult);
                }
                else
                {
                    // negative
                    string unusedIndexValue = rand.NextWord(10);
                    while (usedIndexValues.Contains(unusedIndexValue))
                    {
                        unusedIndexValue = rand.NextWord(10);
                    }

                    string propName = rand.NextItem(possibleProperties);

                    queries.Add(unusedIndexValue + " " + propName);
                    queryResults.Add("[not found]");
                }
            }

            List<string> inputLines = new List<string>();
            inputLines.Add(index);
            inputLines.AddRange(objects.Select(o => GetString(o)).ToList());
            inputLines.Add("[queries]");
            inputLines.AddRange(queries);
            inputLines.Add("end");

            System.IO.File.WriteAllLines(testName + ".in.txt", inputLines);
            System.IO.File.WriteAllLines(testName + ".out.txt", queryResults);
        }

        static string GetString(Dictionary<string, string> obj)
        {
            return string.Join(" ", obj.Keys.Select(k => k + " " + obj[k]));
        }
    }

    static class RandomExtensions
    {
        public static void NextShuffle<T>(this Random r, List<T> list)
        {
            for (int repeats = 0; repeats < 10; repeats++)
            {
                for (int i = 0; i < list.Count; i++)
                {
                    int otherInd = r.Next(0, list.Count);
                    var swap = list[i];
                    list[i] = list[otherInd];
                    list[otherInd] = swap;
                }
            }
        }

        public static int NextIndex<T>(this Random r, ICollection<T> range)
        {
            return r.Next(0, range.Count);
        }

        public static T NextItem<T>(this Random r, IList<T> range)
        {
            return range[r.Next(0, range.Count)];
        }

        public static string NextWord(this Random r, int length)
        {
            char[] word = new char[length];

            for (int i = 0; i < word.Length; i++)
            {
                word[i] = (char)(r.Next() % 2 == 0 ? r.Next('A', 'Z' + 1) : r.Next('a', 'z' + 1));
            }

            return new string(word);
        }

        public static string NextWordOrNumber(this Random r, int length)
        {
            char[] word = new char[length];

            for (int i = 0; i < word.Length; i++)
            {
                word[i] = (char) (r.Next() % 2 == 0 ?
                    (r.Next() % 2 == 0 ? r.Next('A', 'Z' + 1) : r.Next('a', 'z' + 1))
                    : (r.Next('0', '9' + 1)));
            }

            return new string(word);
        }

        public static string NextReplaceN(this Random r, string s, char replaceChar, int count)
        {
            StringBuilder result = new StringBuilder(s);

            for (int i = 0; i < count; i++)
            {
                result[r.Next(0, s.Length)] = replaceChar;
            }

            return result.ToString();
        }

        public static List<double> NextUniqueDoubles(this Random r, int count, double min = -double.MaxValue / 2, double max = double.MaxValue / 2, int digitsAfterPoint = 2)
        {
            HashSet<double> unique = new HashSet<double>();

            double range = max - min;
            while (unique.Count < count)
            {
                double number = double.Parse((min + range * r.NextDouble()).ToString("#." + new string('#', digitsAfterPoint)));
                unique.Add(number);
            }

            return unique.ToList();
        }

        public static bool NextChance(this Random r, double odds0To1)
        {
            return r.NextDouble() < odds0To1;
        }
    }
}
