﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterferenceTestGenerator
{
    class Program
    {
        static Random rand = new Random();

        static void Main(string[] args)
        {
            GenerateTest("test.001", 3, 2, 1, 2);
            GenerateTest("test.002", 5, 2, 10, 10);
            GenerateTest("test.003", 10, 10, 1, 10);
            GenerateTest("test.004", 10, 5, 1, 1);
            GenerateTest("test.005", 10, 20, 5, 20);

            GenerateTest("test.006", 10, 20, 19, 120);
            GenerateTest("test.007", 50, 200, 10, 350);
            GenerateTest("test.008", 100, 10, 15, 480);
            GenerateTest("test.009", 20, 50, 3, 1000);
            GenerateTest("test.010", 100, 50, 5, 1000);
        }

        static void GenerateTest(string testName, int messagesCount, int minTransmissionsPerMessage, int maxInterference, int queriesCount)
        {
            const int MaxWordLength = 20;
            const int MinWordLength = 1;

            List<string> messages = new List<string>();
            List<string> messagesWithCodes = new List<string>();
            HashSet<int> codes = new HashSet<int>();

            List<List<string>> transmittedMessages = new List<List<string>>();
            List<double> frequencies;

            Dictionary<double, string> messagesByFrequency = new Dictionary<double, string>();

            for (int i = 0; i < messagesCount; i++)
            {
                string message = rand.NextWord(rand.Next(MinWordLength, MaxWordLength));
                int priority = rand.Next(0, int.MaxValue);

                while (codes.Contains(priority))
                {
                    priority = rand.Next(0, int.MaxValue);
                }

                messages.Add(message);
                string messageWithCode = message.Insert(rand.Next(0, message.Length), priority.ToString());
                messagesWithCodes.Add(messageWithCode);
                codes.Add(priority);

                transmittedMessages.Add(GenerateTransmittedMessages(messageWithCode, minTransmissionsPerMessage, maxInterference));
            }

            frequencies = rand.NextUniqueDoubles(transmittedMessages.Count, 80, 20000, 2);

            for (int i = 0; i < messagesWithCodes.Count; i++)
            {
                messagesByFrequency[frequencies[i]] = messagesWithCodes[i];
            }

            List<string> inputLines = new List<string>();
            for (int i = 0; i < transmittedMessages.Count; i++)
            {
                double frequency = frequencies[i];
                List<string> messagesForFrequency = transmittedMessages[i];
                inputLines.AddRange(messagesForFrequency.Select(m => frequency + " " + m));
            }

            for (int i = 0; i < queriesCount; i++)
            {
                inputLines.Add("report");
            }

            for (int i = 0; i < inputLines.Count; i++)
            {
                rand.NextShuffle(inputLines);
            }

            Dictionary<double, StringBuilder> receivedMessages = new Dictionary<double, StringBuilder>();
            foreach (var item in messagesByFrequency)
            {
                receivedMessages[item.Key] = new StringBuilder(new string('?', item.Value.Length));
            }

            List<string> outputLines = new List<string>();
            SortedDictionary<int, string> receivedMessagesByCode = new SortedDictionary<int, string>();
            SortedSet<int> receivedCodes = new SortedSet<int>();
            foreach(var inputLine in inputLines)
            {
                if (inputLine == "report")
                {
                    if (receivedCodes.Count == 0)
                    {
                        outputLines.Add("[no new messages]");
                    }
                    else
                    {
                        outputLines.Add(receivedMessagesByCode[receivedCodes.Last()]);
                        receivedCodes.Remove(receivedCodes.Last());
                    }
                }
                else
                {
                    string[] frequencyAndMessage = inputLine.Split(' ');
                    double f = double.Parse(frequencyAndMessage[0]);
                    string message = frequencyAndMessage[1];

                    StringBuilder receivedMessage = receivedMessages[f];
                    for (int i = 0; i < message.Length; i++)
                    {
                        receivedMessage[i] = receivedMessage[i] == '?' ? message[i] : receivedMessage[i];
                    }

                    if (receivedMessage.ToString().Count(c => c == '?') == 0)
                    {
                        int code = int.Parse(string.Join("", receivedMessage.ToString().Where(c => char.IsDigit(c))));
                        string actualMessage = string.Join("", receivedMessage.ToString().Where(c => !char.IsDigit(c)));

                        if (!receivedMessagesByCode.ContainsKey(code))
                        {
                            receivedMessagesByCode[code] = actualMessage;
                            receivedCodes.Add(code);
                        }
                    }
                }
            }

            inputLines.Add("end");

            System.IO.File.WriteAllLines(testName + ".in.txt", inputLines);
            System.IO.File.WriteAllLines(testName + ".out.txt", outputLines);
        }

        static List<string> GenerateTransmittedMessages(string messageWithCode, int minTransmissionsPerMessage, int maxInterference)
        {
            HashSet<int> nonInterferenceIndices = new HashSet<int>();

            List<string> transmissions = new List<string>();
            while (transmissions.Count < minTransmissionsPerMessage || nonInterferenceIndices.Count < messageWithCode.Length)
            {
                string transmissionWithInterference = rand.NextReplaceN(messageWithCode, '?', rand.Next(0, maxInterference));
                for (int i = 0; i < transmissionWithInterference.Length; i++)
                {
                    if (transmissionWithInterference[i] != '?')
                    {
                        nonInterferenceIndices.Add(i);
                    }
                }
                transmissions.Add(transmissionWithInterference);
            }

            return transmissions;
        }

        static void Assert(bool condition)
        {
            if (!condition)
            {
                throw new Exception("assertion failed");
            }
        }
    }

    static class RandomExtensions
    {
        public static void NextShuffle<T>(this Random r, List<T> list)
        {
            for (int repeats = 0; repeats < 10; repeats++)
            {
                for (int i = 0; i < list.Count; i++)
                {
                    int otherInd = r.Next(0, list.Count);
                    var swap = list[i];
                    list[i] = list[otherInd];
                    list[otherInd] = swap;
                }
            }
        }

        public static int NextIndex<T>(this Random r, ICollection<T> range)
        {
            return r.Next(0, range.Count);
        }

        public static string NextWord(this Random r, int length)
        {
            char[] word = new char[length];

            for (int i = 0; i < word.Length; i++)
            {
                word[i] = (char)(r.Next() % 2 == 0 ? r.Next('A', 'Z' + 1) : r.Next('a', 'z' + 1));
            }

            return new string(word);
        }

        public static string NextReplaceN(this Random r, string s, char replaceChar, int count)
        {
            StringBuilder result = new StringBuilder(s);

            for (int i = 0; i < count; i++)
            {
                result[r.Next(0, s.Length)] = replaceChar;
            }

            return result.ToString();
        }

        public static List<double> NextUniqueDoubles(this Random r, int count, double min = -double.MaxValue / 2, double max = double.MaxValue / 2, int digitsAfterPoint = 2)
        {
            HashSet<double> unique = new HashSet<double>();

            double range = max - min;
            while (unique.Count < count)
            {
                double number = double.Parse((min + range * r.NextDouble()).ToString("#." + new string('#', digitsAfterPoint)));
                unique.Add(number);
            }

            return unique.ToList();
        }
    }
}
