﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtremesTestGenerator
{
    class Program
    {
        static Random rand = new Random();

        static void Main(string[] args)
        {
            GenerateTest("test.001", 3, 5, 2);
            GenerateTest("test.002", 0, 5, 2);
            GenerateTest("test.003", 10, 50, 40);
            GenerateTest("test.004", 7, 50, 5);
            GenerateTest("test.005", 4, 15, 1);

            GenerateTest("test.006", 30, 500, 20);
            GenerateTest("test.007", 0, 50, 20);
            GenerateTest("test.008", 100, 500, 400);
            GenerateTest("test.009", 70, 500, 50);
            GenerateTest("test.010", 4, 150, 1);
        }

        static void GenerateTest(string testName, int extremesDist, int valuesCount, int valuesInCalculationCount)
        {
            int distBetweenExtremes = extremesDist * 2 + (valuesCount - valuesInCalculationCount) * rand.Next(2, 10);

            int min = rand.Next(-10000, 10000 - distBetweenExtremes * 2);
            int max = rand.Next(min + distBetweenExtremes + 1, 10000);

            List<int> values = new List<int>();
            List<int> valuesInCalculation = new List<int>();
            for (int i = 0; i < valuesInCalculationCount; i++)
            {
                int valueInCalculation = rand.Next(min + extremesDist + 1, max - extremesDist);
                values.Add(valueInCalculation);
                valuesInCalculation.Add(valueInCalculation);
            }

            for (int i = valuesInCalculationCount; i < valuesCount - 2; i++)
            {
                int offset = rand.Next(0, extremesDist);
                int numberWithinExtremes = (rand.Next(0, 2) == 1 ? min + offset : max - offset);
                values.Add(numberWithinExtremes);
            }

            values.Add(min);
            values.Add(max);

            Shuffle(values);

            double average = 0;
            foreach (var item in valuesInCalculation)
            {
                average += item;
            }
            average /= valuesInCalculation.Count;

            Assert(valuesCount == values.Count);
            Assert(average == CalculateAnswer(values, extremesDist));

            StringBuilder input = new StringBuilder();
            input.AppendLine(extremesDist + "");
            input.AppendLine(valuesCount + "");
            input.AppendLine(string.Join(" ", values));

            System.IO.File.WriteAllText(testName + ".in.txt", input.ToString());
            System.IO.File.WriteAllText(testName + ".out.txt", average.ToString());
        }

        static double CalculateAnswer(List<int> values, int extremesDist)
        {
            int min = values.Min();
            int max = values.Max();

            return values.Where(value => min + extremesDist < value && value < max - extremesDist).Average();
        }

        static void Assert(bool condition)
        {
            if (!condition)
            {
                throw new Exception("assertion failed");
            }
        }

        static void Shuffle<T>(List<T> list)
        {
            for (int repeats = 0; repeats < 10; repeats++)
            {
                for (int i = 0; i < list.Count; i++)
                {
                    int otherInd = rand.Next(0, list.Count);
                    var swap = list[i];
                    list[i] = list[otherInd];
                    list[otherInd] = swap;
                }
            }
        }
    }
}
