﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DecryptionTestGenerator
{
    class Program
    {
        class EncryptedGroup
        {
            public List<string> Group { get; set; }
            public string Encryption { get; set; }

            public EncryptedGroup(List<string> group, string encryption)
            {
                this.Group = group;
                this.Encryption = encryption;
            }
        }

        static Random r = new Random();

        static void Main(string[] args)
        {
            GenerateTest("test.001", 2, 3, "stroke", 2);
            GenerateTest("test.002", 2, 3, "oh anny", 1);
            GenerateTest("test.003", 5, 8, "supreme leader", 5);
            GenerateTest("test.004", 5, 8, "may the false be with you", 3);
            GenerateTest("test.005", 10, 10, "now hear this", 10);

            GenerateTest("test.006", 10, 10, "stroke", 10);
            GenerateTest("test.007", 20, 50, "oh anny", 1);
            GenerateTest("test.008", 40, 50, "supreme leader", 2);
            GenerateTest("test.009", 90, 100, "may the false be with you", 90);
            GenerateTest("test.010", 100, 100, "now hear this", 99);
        }

        static void GenerateTest(string testName, int totalGroups, int maxGroupSize, string prefix, int knownEncryptionsCount)
        {
            HashSet<string> uniqueMessages = new HashSet<string>();

            while (uniqueMessages.Count < totalGroups * maxGroupSize)
            {
                uniqueMessages.Add(prefix + (r.NextChance(0.8) ? " " : "") + r.NextText(r.Next(10, 100)));
            }

            HashSet<string> encryptions = new HashSet<string>();

            List<List<string>> messageGroups = new List<List<string>>();
            HashSet<int> groupSizes = new HashSet<int>();
            while (messageGroups.Count < totalGroups)
            {
                int groupSize = r.Next(1, maxGroupSize);
                while (groupSizes.Contains(groupSize))
                {
                    groupSize = r.Next(1, maxGroupSize + 1);
                }

                messageGroups.Add(uniqueMessages.PopFirst(groupSize));
                groupSizes.Add(groupSize);
            }

            Dictionary<string, EncryptedGroup> encryptedGroupsByEncryptedPrefix = new Dictionary<string, EncryptedGroup>();

            foreach (List<string> group in messageGroups)
            {
                string encryption = GetEncryption();
                while (encryptedGroupsByEncryptedPrefix.ContainsKey(Encrypt(prefix, GetCharMap(encryption))))
                {
                    encryption = GetEncryption();
                }

                Dictionary<char, char> charMap = GetCharMap(encryption);
                List<string> encryptedGroup = group.Select(m => Encrypt(m, charMap)).ToList();

                encryptedGroupsByEncryptedPrefix[Encrypt(prefix, charMap)] = new EncryptedGroup(encryptedGroup, encryption);
            }

            List<EncryptedGroup> encryptedGroups = encryptedGroupsByEncryptedPrefix.Select(kv => kv.Value).OrderBy(g => g.Group.Count).ToList();

            EncryptedGroup answerGroup = encryptedGroups[knownEncryptionsCount - 1];
            List<string> knownEncryptions = encryptedGroups.GetRange(0, knownEncryptionsCount).Select(g => g.Encryption).ToList();
            r.NextShuffle(knownEncryptions);

            //List<string> messages = encryptedGroups.SelectMany(g => g.Group).ToList();
            List<string> messages = new List<string>();
            foreach (var messageGroup in encryptedGroups)
            {
                int lastInsert = 0;
                foreach (var message in messageGroup.Group)
                {
                    int insert = messages.Count == 0 ? 0 : r.Next(lastInsert + 1, messages.Count + 1);
                    messages.Insert(insert, message);
                    lastInsert = insert;
                }
            }


            List<string> inputLines = new List<string>();
            inputLines.Add(prefix);
            inputLines.AddRange(messages);
            inputLines.Add("[encryptions]");
            inputLines.AddRange(knownEncryptions);
            inputLines.Add("[end]");

            Dictionary<char, char> decryptMap = GetCharMap(answerGroup.Encryption).ToDictionary(kv => kv.Value, kv => kv.Key);
            List<string> outputLines = answerGroup.Group.Select(m => Encrypt(m, decryptMap)).ToList();

            System.IO.File.WriteAllLines(testName + ".in.txt", inputLines);
            System.IO.File.WriteAllLines(testName + ".out.txt", outputLines);
        }

        static Dictionary<char, char> GetCharMap(string encryption)
        {
            Dictionary<char, char> charMap = new Dictionary<char, char>();

            for (char actualLetter = 'a'; actualLetter <= 'z'; actualLetter++)
            {
                charMap[actualLetter] = encryption[actualLetter - 'a'];
            }

            return charMap;
        }

        static string Encrypt(string s, Dictionary<char, char> charMap)
        {
            char[] chars = new char[s.Length];

            for (int i = 0; i < s.Length; i++)
            {
                if (char.IsLetter(s[i]))
                {
                    chars[i] = charMap[s[i]];
                }
                else
                {
                    chars[i] = s[i];
                }
            }

            return string.Join("", chars);
        }

        static string GetEncryption()
        {
            List<char> encryption = "abcdefghijklmnopqrstuvwxyz".ToList();

            r.NextShuffle(encryption);

            return string.Join("", encryption);
        }
    }

    static class HashSetExtensions
    {
        public static List<T> PopFirst<T>(this HashSet<T> set, int count)
        {
            List<T> items = new List<T>();

            while(items.Count < count && set.Count > 0)
            {
                items.Add(set.First());
                set.Remove(set.First());
            }

            return items;
        }
    }

    static class RandomExtensions
    {
        public static void NextShuffle<T>(this Random r, List<T> list)
        {
            for (int repeats = 0; repeats < 10; repeats++)
            {
                for (int i = 0; i < list.Count; i++)
                {
                    int otherInd = r.Next(0, list.Count);
                    var swap = list[i];
                    list[i] = list[otherInd];
                    list[otherInd] = swap;
                }
            }
        }

        public static int NextIndex<T>(this Random r, ICollection<T> range)
        {
            return r.Next(0, range.Count);
        }

        public static T NextItem<T>(this Random r, IList<T> range)
        {
            return range[r.Next(0, range.Count)];
        }

        public static string NextWord(this Random r, int length)
        {
            char[] word = new char[length];

            for (int i = 0; i < word.Length; i++)
            {
                word[i] = (char)(r.Next() % 2 == 0 ? r.Next('A', 'Z' + 1) : r.Next('a', 'z' + 1));
            }

            return new string(word);
        }

        public static string NextText(this Random r, int length)
        {
            char[] text = new char[length];
            for (int i = 0; i < text.Length; i++)
            {
                text[i] = i < length - 1 && i != 0 && char.IsLetter(text[i - 1]) && NextChance(r, 0.1) ? 
                    ' ' : (char)r.Next('a', 'z' + 1);
            }

            return string.Join("", text);
        }

        public static string NextWordOrNumber(this Random r, int length)
        {
            char[] word = new char[length];

            for (int i = 0; i < word.Length; i++)
            {
                word[i] = (char)(r.Next() % 2 == 0 ?
                    (r.Next() % 2 == 0 ? r.Next('A', 'Z' + 1) : r.Next('a', 'z' + 1))
                    : (r.Next('0', '9' + 1)));
            }

            return new string(word);
        }

        public static string NextReplaceN(this Random r, string s, char replaceChar, int count)
        {
            StringBuilder result = new StringBuilder(s);

            for (int i = 0; i < count; i++)
            {
                result[r.Next(0, s.Length)] = replaceChar;
            }

            return result.ToString();
        }

        public static List<double> NextUniqueDoubles(this Random r, int count, double min = -double.MaxValue / 2, double max = double.MaxValue / 2, int digitsAfterPoint = 2)
        {
            HashSet<double> unique = new HashSet<double>();

            double range = max - min;
            while (unique.Count < count)
            {
                double number = double.Parse((min + range * r.NextDouble()).ToString("#." + new string('#', digitsAfterPoint)));
                unique.Add(number);
            }

            return unique.ToList();
        }

        public static bool NextChance(this Random r, double odds0To1)
        {
            return r.NextDouble() < odds0To1;
        }

        public static List<T> NextUniqueSubset<T>(this Random r, ISet<T> set)
        {
            int count = r.Next(1, set.Count + 1);

            List<T> list = new List<T>(set);
            r.NextShuffle(list);

            return list.GetRange(0, count);
        }
    }
}
