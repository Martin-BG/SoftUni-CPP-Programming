﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DecompressionTestGenerator
{
    class Program
    {
        static Random rand = new Random();

        static void Main(string[] args)
        {
            GenerateTest("test.001", 10, 5);
            GenerateTest("test.002", 10, 2);
            GenerateTest("test.003", 20, 3);
            GenerateTest("test.004", 20, 10);
            GenerateTest("test.005", 1, 50);

            GenerateTest("test.006", 100, 5);
            GenerateTest("test.007", 100, 20);
            GenerateTest("test.008", 200, 3);
            GenerateTest("test.009", 200, 100);
            GenerateTest("test.010", 1, 500);
        }

        static void GenerateTest(string testName, int numSequences, int maxSequence)
        {
            int generatedLength = 0;
            List<string> compressedSequences = new List<string>();
            for (int i = 0; i < numSequences; i++)
            {
                char c;
                if (i > 0)
                {
                    string last = compressedSequences[compressedSequences.Count - 1];
                    do
                    {
                        c = (char)rand.Next('a', 'z' + 1);
                    } while (c == last[last.Length - 1]);
                }
                else
                {
                    c = (char)rand.Next('a', 'z' + 1);
                }

                int length = rand.Next(1, maxSequence + 1);

                string compressed = length > 2 ? length.ToString() + c : new string(c, length);
                generatedLength += compressed.Length;
                compressedSequences.Add(compressed);
            }

            StringBuilder text = new StringBuilder();
            foreach (var compressed in compressedSequences)
            {
                string lengthPart = compressed.Substring(0, compressed.Length - 1);
                if (int.TryParse(lengthPart, out int length))
                {
                    text.Append(new string(compressed[compressed.Length - 1], length));
                }
                else
                {
                    text.Append(compressed);
                }
            }

            System.IO.File.WriteAllText(testName + ".in.txt", string.Join("", compressedSequences));
            System.IO.File.WriteAllText(testName + ".out.txt", text.ToString());
        }

        static void Assert(bool condition)
        {
            if (!condition)
            {
                throw new Exception("assertion failed");
            }
        }

        static void Shuffle<T>(List<T> list)
        {
            for (int repeats = 0; repeats < 10; repeats++)
            {
                for (int i = 0; i < list.Count; i++)
                {
                    int otherInd = rand.Next(0, list.Count);
                    var swap = list[i];
                    list[i] = list[otherInd];
                    list[otherInd] = swap;
                }
            }
        }
    }
}
