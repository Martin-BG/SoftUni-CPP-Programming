﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnusedTestGenerator
{
    class Program
    {
        static Random rand = new Random();

        static void Main(string[] args)
        {
            int totalEnglishLetters = 'z' - 'a' + 1;

            GenerateTest("test.001", 10, 3);
            GenerateTest("test.002", 10, 9);
            GenerateTest("test.003", 30, 1);
            GenerateTest("test.004", 30, 20);
            GenerateTest("test.005", 50, totalEnglishLetters - 1);

            GenerateTest("test.006", 50, totalEnglishLetters - 1);
            GenerateTest("test.007", 50, totalEnglishLetters / 2);
            GenerateTest("test.008", 80, (int)(totalEnglishLetters / 1.5));
            GenerateTest("test.009", 100, 1);
            GenerateTest("test.010", 100, totalEnglishLetters - 1);
        }

        private static void GenerateTest(string testName, int lettersCount, int usedLettersCount)
        {
            SortedSet<char> usedLetters = new SortedSet<char>();

            while (usedLetters.Count < usedLettersCount)
            {
                usedLetters.Add(rand.NextEnglishLetter(false));
            }

            List<char> inputLetters = new List<char>(usedLetters);
            rand.NextShuffle(inputLetters);

            while (inputLetters.Count < lettersCount)
            {
                inputLetters.Add(inputLetters[rand.NextIndex(inputLetters)]);
            }

            List<char> unusedLetters = new List<char>();
            for (char i = 'a'; i <= 'z'; i++)
            {
                if (!usedLetters.Contains(i))
                {
                    unusedLetters.Add(i);
                }
            }

            System.IO.File.WriteAllLines(testName + ".in.txt", new List<string>() { string.Join("", inputLetters) });
            System.IO.File.WriteAllLines(testName + ".out.txt", new List<string>() { string.Join("", unusedLetters) });
        }
    }

    static class RandomExtensions
    {
        public static void NextShuffle<T>(this Random r, List<T> list)
        {
            for (int repeats = 0; repeats < 10; repeats++)
            {
                for (int i = 0; i < list.Count; i++)
                {
                    int otherInd = r.Next(0, list.Count);
                    var swap = list[i];
                    list[i] = list[otherInd];
                    list[otherInd] = swap;
                }
            }
        }

        public static int NextIndex<T>(this Random r, ICollection<T> range)
        {
            return r.Next(0, range.Count);
        }

        public static string NextWord(this Random r, int length)
        {
            char[] word = new char[length];

            for (int i = 0; i < word.Length; i++)
            {
                word[i] = (char)(r.Next() % 2 == 0 ? r.Next('A', 'Z' + 1) : r.Next('a', 'z' + 1));
            }

            return new string(word);
        }

        public static char NextEnglishLetter(this Random r, bool capital)
        {
            return (char) (capital ? r.Next('A', 'Z' + 1) : r.Next('a', 'z' + 1));
        }

        public static string NextReplaceN(this Random r, string s, char replaceChar, int count)
        {
            StringBuilder result = new StringBuilder(s);

            for (int i = 0; i < count; i++)
            {
                result[r.Next(0, s.Length)] = replaceChar;
            }

            return result.ToString();
        }

        public static List<double> NextUniqueDoubles(this Random r, int count, double min = -double.MaxValue / 2, double max = double.MaxValue / 2, int digitsAfterPoint = 2)
        {
            HashSet<double> unique = new HashSet<double>();

            double range = max - min;
            while (unique.Count < count)
            {
                double number = double.Parse((min + range * r.NextDouble()).ToString("#." + new string('#', digitsAfterPoint)));
                unique.Add(number);
            }

            return unique.ToList();
        }
    }
}
