﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClosestTownsTestGenerator
{
    class Program
    {
        class Vector2D
        {
            public double x;
            public double y;

            public Vector2D(double x, double y)
            {
                this.x = x;
                this.y = y;
            }

            public static Vector2D operator-(Vector2D a, Vector2D b)
            {
                return new Vector2D(a.x - b.x, a.y - b.y);
            }

            public double length()
            {
                return Math.Sqrt(this.x * this.x + this.y * this.y);
            }

            // override object.Equals
            public override bool Equals(object obj)
            {
                //       
                // See the full list of guidelines at
                //   http://go.microsoft.com/fwlink/?LinkID=85237  
                // and also the guidance for operator== at
                //   http://go.microsoft.com/fwlink/?LinkId=85238
                //

                if (obj == null || GetType() != obj.GetType())
                {
                    return false;
                }

                Vector2D other = obj as Vector2D;
                return this.x == other.x && this.y == other.y;
            }

            // override object.GetHashCode
            public override int GetHashCode()
            {
                return (this.x + " " + this.y).GetHashCode();
            }
        }

        static Random rand = new Random();

        static void Main(string[] args)
        {
            generateTest("test.001", 5, 10);
            generateTest("test.002", 10, 10);
            generateTest("test.003", 30, 25);
            generateTest("test.004", 40, 25);
            generateTest("test.005", 50, 50);
            generateTest("test.006", 60, 300);
            generateTest("test.007", 70, 999);
            generateTest("test.008", 80, 500);
            generateTest("test.009", 90, 100);
            generateTest("test.010", 99, 25);
        }

        static string[] townNames =
        {
"Townsville",
"Hobart",
"Geelong",
"LoganCity",
"Wollongong",
"Newcastle",
"Canberra",
"GoldCoast",
"Adelaide",
"Perth",
"Brisbane",
"Melbourne",
"Sydney",
"Bakixanov",
"Sirvan",
"Qaracuxur",
"Saatli",
"Mingelchaur",
"Lankaran",
"Sumqayit",
"Ganja",
"Baku",
"Bihac",
"Mostar",
"Tuzla",
"Zenica",
"Brugge",
"Liege",
"Charleroi",
"Gent",
"Antwerpen",
"Brussels",
"Koudougou",
"BoboDioulasso",
"Ouagadougou",
"Gabrovo",
"VelikoTurnovo",
"Blagoevgrad",
"Pazardzhik",
"Haskovo",
"Yambol",
"Pernik",
"Shumen",
"Dobrich",
"Sliven",
"Pleven",
"StaraZagora",
"Ruse",
"Burgas",
"Varna",
"Plovdiv",
"Sofia",
"ArRifa'",
"AlMuharraq",
"Manama",
"Muyinga",
"Bujumbura",
"Save",
"Natitingou",
"Abomey",
"Ouidah",
"Lokossa",
"Kandi",
"Bohicon",
"Parakou",
"Porto",
"Bage",
"SantanadeParnaiba",
"Sertaozinho",
"Votorantim",
"Itabira",
"RiodasOstras",
"Itaguai",
"CoronelFabriciano",
"Guarapari",
"Guaiba",
"TeofiloOtoni",
"Colatina",
"Barretos",
"Assis",
"Birigui",
"Esmeraldas",
"Araguaina",
"Linhares",
"Guaratingueta",
"SantaCruzdoSul",
"Apucarana",
"Umuarama",
"VitoriadeSantoAntao",
"Poa",
"Araras",
"JiParana",
"CaboFrio",
"FrancodaRocha",
"Catanduva",
"Araruama",
"Kalulushi",
"Chipata",
"Livingstone",
"Luanshya",
"Mufulira",
"Chingola",
"Kabwe",
"Ndola",
"Kitwe",
"Lusaka",
"Masvingo",
"Kadoma",
"Kwekwe",
"Epworth",
"Gweru",
"Mutare"
        };

        private static void generateTest(string testName, int pointsCount, int maxCoord)
        {
            HashSet<string> usedNames = new HashSet<string>();
            HashSet<Vector2D> usedPositions = new HashSet<Vector2D>();

            List<string> townNames = new List<string>();
            List<Vector2D> townPositions = new List<Vector2D>();

            for (int i = 0; i < pointsCount; i++)
            {
                Vector2D point = getRandomPoint(usedPositions, maxCoord);
                string name = getRandomName(usedNames);
                usedPositions.Add(point);
                usedNames.Add(name);

                townNames.Add(name);
                townPositions.Add(point);
            }

            int closestPairAInd = 0, closestPairBInd = 1;
            double closestDist = (townPositions[closestPairAInd] - townPositions[closestPairBInd]).length();

            for (int aInd = 0; aInd < townPositions.Count; aInd++)
            {
                for (int bInd = 0; bInd < townPositions.Count; bInd++)
                {
                    if (aInd == bInd)
                    {
                        continue;
                    }

                    double currentDist = (townPositions[aInd] - townPositions[bInd]).length();
                    if (currentDist < closestDist)
                    {
                        closestPairAInd = aInd;
                        closestPairBInd = bInd;
                        closestDist = currentDist;
                    }
                }
            }

            StringBuilder inputBuilder = new StringBuilder();
            inputBuilder.AppendLine(townNames.Count + "");
            for (int i = 0; i < townNames.Count; i++)
            {
                inputBuilder.AppendLine(townNames[i] + " " + townPositions[i].x + " " + townPositions[i].y);
            }

            string output = townNames[closestPairAInd] + "-" + townNames[closestPairBInd];

            System.IO.File.WriteAllText(testName + ".in.txt", inputBuilder.ToString());
            System.IO.File.WriteAllText(testName + ".out.txt", output.ToString());
        }

        private static Vector2D getRandomPoint(HashSet<Vector2D> notAllowed, int maxCoord)
        {
            Vector2D p = new Vector2D(rand.Next(-maxCoord, maxCoord + 1), rand.Next(-maxCoord, maxCoord + 1));
            while (notAllowed.Contains(p))
            {
                p = new Vector2D(rand.Next(-maxCoord, maxCoord + 1), rand.Next(-maxCoord, maxCoord + 1));
            }

            return p;
        }

        private static string getRandomName(HashSet<string> notAllowed)
        {
            string name = townNames[rand.Next(0, townNames.Length)];
            while (notAllowed.Contains(name))
            {
                name = townNames[rand.Next(0, townNames.Length)];
            }

            return name;
        }
    }
}
