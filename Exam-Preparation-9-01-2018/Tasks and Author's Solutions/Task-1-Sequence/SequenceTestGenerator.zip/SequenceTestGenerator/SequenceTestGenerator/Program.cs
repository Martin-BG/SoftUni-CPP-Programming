﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SequenceTestGenerator
{
    class Program
    {
        static Random rand = new Random();

        static void Main(string[] args)
        {
            GenerateTest("test.001", 10, 4);
            GenerateTest("test.002", 10, 2);
            GenerateTest("test.003", 10, 10);
            GenerateTest("test.004", 10, 9);
            GenerateTest("test.005", 10, 1);

            GenerateTest("test.006", 1000, 400);
            GenerateTest("test.007", 1000, 200);
            GenerateTest("test.008", 1000, 1000);
            GenerateTest("test.009", 1000, 900);
            GenerateTest("test.010", 1000, 100);
        }

        static void GenerateTest(string testName, int totalCount, int longestIncreasingCount)
        {
            List<List<int>> sequences = new List<List<int>>();

            List<int> longestIncreasing = rand.NextIncreasingSequence(longestIncreasingCount);
            int generatedCount = longestIncreasingCount;
            while (generatedCount < totalCount)
            {
                List<int> sequence;
                if (sequences.Count > 0)
                {
                    sequence = rand.NextIncreasingSequence(Math.Min(longestIncreasingCount - 1, totalCount - generatedCount),
                        rand.Next(int.MinValue, sequences.Last().Last()),
                        100);
                }
                else
                {
                    sequence = rand.NextIncreasingSequence(Math.Min(longestIncreasingCount - 1, totalCount - generatedCount));
                }
                sequences.Add(sequence);
                generatedCount += sequence.Count;
            }

            List<int> possibleInserts = new List<int>();

            if (sequences.Count == 0 || longestIncreasing[longestIncreasing.Count - 1] > sequences[0][0])
            {
                possibleInserts.Add(0);
            }

            for (int i = 1; i < sequences.Count; i++)
            {
                if (sequences[i - 1].Last() > longestIncreasing[0] && longestIncreasing[longestIncreasing.Count - 1] > sequences[i][0])
                {
                    possibleInserts.Add(i);
                }
            }

            if (sequences.Count == 0 || sequences.Last().Last() > longestIncreasing[0])
            {
                possibleInserts.Add(sequences.Count);
            }

            sequences.Insert(rand.NextItem(possibleInserts), longestIncreasing);

            List<int> totalSequence = sequences.SelectMany(s => s).ToList();
            if (totalSequence.Count != totalCount)
            {
                throw new Exception();
            }

            if (longestIncreasing.Count > 1)
            { 
                AssertEquals(longestIncreasing, FindLongestIncreasingSequence(totalSequence));
            }
            else
            {
                AssertEquals(longestIncreasingCount, FindLongestIncreasingSequence(totalSequence).Count);
            }

            System.IO.File.WriteAllLines(testName + ".in.txt", new string[] { totalSequence.Count.ToString(), string.Join(" ", totalSequence) });
            System.IO.File.WriteAllLines(testName + ".out.txt", new string[] { longestIncreasing.Count.ToString() });
        }

        static List<int> FindLongestIncreasingSequence(List<int> numbers)
        {
            List<int> maxSequence = new List<int>();

            for (int a = 0; a < numbers.Count; a++)
            {
                List<int> current = new List<int>();
                current.Add(numbers[a]);
                for (int b = a + 1; b < numbers.Count; b++)
                {
                    if (numbers[b] > numbers[b - 1])
                    {
                        current.Add(numbers[b]);
                    }
                    else
                    {
                        break;
                    }
                }

                if (current.Count > maxSequence.Count)
                {
                    maxSequence = current;
                }
            }

            return maxSequence;
        }

        static void AssertEquals(int a, int b)
        {
            if (a != b)
            {
                throw new Exception();
            }
        }

        static void AssertEquals<T>(IList<T> a, IList<T> b)
        {
            if (a.Count != b.Count)
            {
                throw new Exception("size difference");
            }

            for (int i = 0; i < a.Count; i++)
            {
                if (!a[i].Equals(b[i]))
                {
                    throw new Exception("difference at " + i + ", " + a[i] + "!=" + b[i]);
                }
            }
        }
    }

    static class RandomExtensions
    {
        public static bool NextBoolean(this Random r)
        {
            return (r.Next() & 1) != 0;
        }

        public static List<int> NextSequence(this Random r, int count)
        {
            var sequence = r.NextIncreasingSequence(count);
            r.NextShuffle(sequence);
            return sequence;
        }

        public static List<int> NextIncreasingSequence(this Random r, int count, int maxStep = 100)
        {
            List<int> sequence = new List<int>();
            sequence.Add(r.Next(int.MinValue, int.MaxValue - count * maxStep));
            while (sequence.Count < count)
            {
                sequence.Add(sequence[sequence.Count - 1] + r.Next(1, maxStep));
            }

            return sequence;
        }

        public static List<int> NextIncreasingSequence(this Random r, int count, int start, int maxStep = 100)
        {
            List<int> sequence = new List<int>();
            sequence.Add(start);
            while (sequence.Count < count)
            {
                sequence.Add(sequence[sequence.Count - 1] + r.Next(1, maxStep));
            }

            return sequence;
        }

        public static void NextShuffle<T>(this Random r, List<T> list)
        {
            for (int repeats = 0; repeats < 10; repeats++)
            {
                for (int i = 0; i < list.Count; i++)
                {
                    int otherInd = r.Next(0, list.Count);
                    var swap = list[i];
                    list[i] = list[otherInd];
                    list[otherInd] = swap;
                }
            }
        }

        public static int NextIndex<T>(this Random r, ICollection<T> range)
        {
            return r.Next(0, range.Count);
        }

        public static T NextItem<T>(this Random r, IList<T> range)
        {
            return range[r.Next(0, range.Count)];
        }

        public static string NextWord(this Random r, int length)
        {
            char[] word = new char[length];

            for (int i = 0; i < word.Length; i++)
            {
                word[i] = (char)(r.Next() % 2 == 0 ? r.Next('A', 'Z' + 1) : r.Next('a', 'z' + 1));
            }

            return new string(word);
        }

        public static string NextWordOrNumber(this Random r, int length)
        {
            char[] word = new char[length];

            for (int i = 0; i < word.Length; i++)
            {
                word[i] = (char)(r.Next() % 2 == 0 ?
                    (r.Next() % 2 == 0 ? r.Next('A', 'Z' + 1) : r.Next('a', 'z' + 1))
                    : (r.Next('0', '9' + 1)));
            }

            return new string(word);
        }

        public static string NextReplaceN(this Random r, string s, char replaceChar, int count)
        {
            StringBuilder result = new StringBuilder(s);

            for (int i = 0; i < count; i++)
            {
                result[r.Next(0, s.Length)] = replaceChar;
            }

            return result.ToString();
        }

        public static List<double> NextUniqueDoubles(this Random r, int count, double min = -double.MaxValue / 2, double max = double.MaxValue / 2, int digitsAfterPoint = 2)
        {
            HashSet<double> unique = new HashSet<double>();

            double range = max - min;
            while (unique.Count < count)
            {
                double number = double.Parse((min + range * r.NextDouble()).ToString("#." + new string('#', digitsAfterPoint)));
                unique.Add(number);
            }

            return unique.ToList();
        }

        public static bool NextChance(this Random r, double odds0To1)
        {
            return r.NextDouble() < odds0To1;
        }
    }
}
