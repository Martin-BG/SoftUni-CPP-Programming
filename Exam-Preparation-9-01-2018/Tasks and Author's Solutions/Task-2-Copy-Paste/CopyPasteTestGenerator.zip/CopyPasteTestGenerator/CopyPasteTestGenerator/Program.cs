﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CopyPasteTestGenerator
{
    class Program
    {
        static Random rand = new Random();

        static void Main(string[] args)
        {
            GenerateTest("test.001", 6, 10, 3, 1);
            GenerateTest("test.002", 10, 3, 3, 1);
            GenerateTest("test.003", 6, 10, 1, 5);
            GenerateTest("test.004", 10, 3, 1, 5);
            GenerateTest("test.005", 10, 10, 10, 10);

            GenerateTest("test.006", 60, 10, 30, 10);
            GenerateTest("test.007", 100, 3, 30, 10);
            GenerateTest("test.008", 60, 10, 10, 50);
            GenerateTest("test.009", 100, 3, 10, 50);
            GenerateTest("test.010", 100, 10, 50, 50);
        }

        static void GenerateTest(string testName, int wordsCount, int maxWordLength, int copiesCount, int pastesCount)
        {
            List<string> words = new List<string>();
            while(words.Count < wordsCount)
            {
                words.Add(rand.NextWord(rand.Next(1, maxWordLength + 1)));
            }

            Stack<List<string>> clipboard = new Stack<List<string>>();

            List<string> inputLines = new List<string>();
            inputLines.Add(string.Join(" ", words));

            while (copiesCount != 0 || pastesCount != 0)
            {
                bool copy = rand.NextChance(copiesCount / (double)pastesCount);
                if (copy)
                {
                    int fromWordInd = rand.NextIndex(words);
                    int toWordInd = rand.NextIndex(words, fromWordInd);

                    clipboard.Push(words.GetRange(fromWordInd, (toWordInd - fromWordInd) + 1));

                    int indexInFrom = rand.NextItem(GetWordTextIndices(words, fromWordInd));
                    int indexInTo = rand.NextItem(GetWordTextIndices(words, toWordInd));

                    if (indexInFrom > indexInTo)
                    {
                        if (fromWordInd != toWordInd) { throw new Exception(); }
                        int oldIndexInFrom = indexInFrom;
                        indexInFrom = indexInTo;
                        indexInTo = oldIndexInFrom;
                    }

                    inputLines.Add("copy " + indexInFrom + " " + indexInTo);
                    copiesCount--;
                }
                else
                {
                    int pastePosition = rand.Next(0, words.Sum(w => w.Length) + (words.Count - 1));
                    if (clipboard.Count > 0)
                    {
                        List<string> copiedWords = clipboard.Pop();

                        Tuple<int, int> wordAndIndex = GetWordAtTextIndex(words, pastePosition);
                        int pasteWordIndex = wordAndIndex.Item1;
                        if (wordAndIndex.Item2 == -1)
                        {
                            words.InsertRange(pasteWordIndex, copiedWords);
                        }
                        else
                        {
                            string splitWord = words[pasteWordIndex];
                            string splitA = splitWord.Substring(0, wordAndIndex.Item2);
                            string splitB = splitWord.Substring(wordAndIndex.Item2);
                            if (copiedWords.Count == 1)
                            {
                                words[pasteWordIndex] = splitA + copiedWords[0] + splitB;
                            }
                            else
                            {
                                List<string> newWords = new List<string>();
                                newWords.Add(splitA + copiedWords[0]);

                                for (int i = 1; i < copiedWords.Count - 1; i++)
                                {
                                    newWords.Add(copiedWords[i]);
                                }

                                newWords.Add(copiedWords[copiedWords.Count - 1] + splitB);

                                words.RemoveAt(pasteWordIndex);
                                words.InsertRange(pasteWordIndex, newWords);
                            }
                        }
                    }

                    inputLines.Add("paste " + pastePosition);
                    pastesCount--;
                }
            }
            inputLines.Add("end");

            System.IO.File.WriteAllLines(testName + ".in.txt", inputLines);
            string result = string.Join(" ", words);

            if (result.Contains("  "))
            {
                throw new Exception();
            }

            System.IO.File.WriteAllLines(testName + ".out.txt", new string[] { result });
        }

        static Tuple<int, int> GetWordAtTextIndex(List<string> words, int textIndex)
        {
            int currentTextIndex = 0;
            int wordIndex = 0;
            int indexInWord = 0;

            while (currentTextIndex < textIndex)
            {
                indexInWord++;
                currentTextIndex++;

                if (indexInWord == words[wordIndex].Length)
                {
                    if (currentTextIndex == textIndex)
                    {
                        return new Tuple<int, int>(wordIndex + 1, -1);
                    }

                    currentTextIndex++; //step into next word
                    indexInWord = 0;
                    wordIndex++;
                }
            }

            return new Tuple<int, int>(wordIndex, indexInWord);

            //currentTextIndex += words[wordIndex].Length;
            //while (currentTextIndex < textIndex)
            //{
            //    currentTextIndex += words[wordIndex].Length;

            //    if (currentTextIndex == textIndex)
            //    {
            //        return new Tuple<int, int>(wordIndex + 1, -1);
            //    }

            //    currentTextIndex += 1;
            //    wordIndex++;
            //}

            //return new Tuple<int, int>(wordIndex, words[wordIndex].Length - (currentTextIndex - textIndex));
        }

        static List<int> GetWordTextIndices(List<string> words, int wordIndex)
        {
            List<int> indices = new List<int>();

            int wordStart = 0;
            for (int i = 0; i < wordIndex; i++)
            {
                wordStart += words[i].Length;
                wordStart += 1; // space
            }

            for (int i = 0; i < words[wordIndex].Length; i++)
            {
                indices.Add(wordStart + i);
            }

            return indices;
        }
    }

    static class RandomExtensions
    {
        public static void NextShuffle<T>(this Random r, List<T> list)
        {
            for (int repeats = 0; repeats < 10; repeats++)
            {
                for (int i = 0; i < list.Count; i++)
                {
                    int otherInd = r.Next(0, list.Count);
                    var swap = list[i];
                    list[i] = list[otherInd];
                    list[otherInd] = swap;
                }
            }
        }

        public static int NextIndex<T>(this Random r, ICollection<T> range, int start = 0)
        {
            return r.Next(start, range.Count);
        }

        public static T NextItem<T>(this Random r, IList<T> range)
        {
            return range[r.Next(0, range.Count)];
        }

        public static string NextWord(this Random r, int length)
        {
            char[] word = new char[length];

            for (int i = 0; i < word.Length; i++)
            {
                word[i] = (char)(r.Next() % 2 == 0 ? r.Next('A', 'Z' + 1) : r.Next('a', 'z' + 1));
            }

            return new string(word);
        }

        public static string NextWordOrNumber(this Random r, int length)
        {
            char[] word = new char[length];

            for (int i = 0; i < word.Length; i++)
            {
                word[i] = (char)(r.Next() % 2 == 0 ?
                    (r.Next() % 2 == 0 ? r.Next('A', 'Z' + 1) : r.Next('a', 'z' + 1))
                    : (r.Next('0', '9' + 1)));
            }

            return new string(word);
        }

        public static string NextReplaceN(this Random r, string s, char replaceChar, int count)
        {
            StringBuilder result = new StringBuilder(s);

            for (int i = 0; i < count; i++)
            {
                result[r.Next(0, s.Length)] = replaceChar;
            }

            return result.ToString();
        }

        public static List<double> NextUniqueDoubles(this Random r, int count, double min = -double.MaxValue / 2, double max = double.MaxValue / 2, int digitsAfterPoint = 2)
        {
            HashSet<double> unique = new HashSet<double>();

            double range = max - min;
            while (unique.Count < count)
            {
                double number = double.Parse((min + range * r.NextDouble()).ToString("#." + new string('#', digitsAfterPoint)));
                unique.Add(number);
            }

            return unique.ToList();
        }

        public static bool NextChance(this Random r, double odds0To1)
        {
            return r.NextDouble() < odds0To1;
        }
    }
}
