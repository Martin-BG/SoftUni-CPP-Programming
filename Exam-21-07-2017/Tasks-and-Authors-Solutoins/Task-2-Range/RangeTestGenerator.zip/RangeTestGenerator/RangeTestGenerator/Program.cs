﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RangeTestGenerator
{
    class Program
    {
        static Random rand = new Random();

        static void Main(string[] args)
        {
            GenerateTest("test.001", 10, 1, 10, 1, 100);
            GenerateTest("test.002", 20, 20, 20, 1, 100);
            GenerateTest("test.003", 30, 20, 30, 0, 10);
            GenerateTest("test.004", 40, 20, 40, -100, 100);
            GenerateTest("test.005", 50, 30, 50, -100, 100);

            GenerateTest("test.006", 100, 10, 5000, 1, 100);
            GenerateTest("test.007", 100, 1000, 6000, -100, 100);
            GenerateTest("test.008", 100, 2000, 7000, -100, 0);
            GenerateTest("test.009", 100, 3000, 8000, -100, -50);
            GenerateTest("test.010", 100, 10000, 10000, -100, 100);
        }

        static void GenerateTest(string testName, int arraysCount, int minArraySize, int maxArraySize, int minValue, int maxValue)
        {
            List<List<int>> arrays = new List<List<int>>();
            HashSet<int> uniqueValues = new HashSet<int>();
            while (arrays.Count < arraysCount)
            {
                int arraySize = rand.Next(minArraySize, maxArraySize + 1);
                List<int> array = new List<int>();
                while (array.Count < arraySize)
                {
                    int value = rand.Next(minValue, maxValue + 1);
                    array.Add(value);
                    uniqueValues.Add(value);
                }

                arrays.Add(array);
            }

            List<int> uniqueValuesList = new List<int>(uniqueValues);

            int query = uniqueValuesList[rand.Next(0, uniqueValuesList.Count)];

            List<int> maxOccurencesArray = arrays[0];
            int maxOccurrences = maxOccurencesArray.Count(v => v == query);
            foreach (var array in arrays)
            {
                int occurrences = array.Count(v => v == query);
                if (occurrences > maxOccurrences)
                {
                    maxOccurrences = occurrences;
                    maxOccurencesArray = array;
                }
            }

            StringBuilder inputBuilder = new StringBuilder();
            foreach (var array in arrays)
            {
                inputBuilder.AppendLine(string.Join(" ", array));
            }

            inputBuilder.AppendLine("end");
            inputBuilder.AppendLine(query + "");

            maxOccurencesArray.Sort();

            System.IO.File.WriteAllText(testName + ".in.txt", inputBuilder.ToString());
            System.IO.File.WriteAllText(testName + ".out.txt", string.Join(" ", maxOccurencesArray));
        }

        static void Shuffle<T>(List<T> list)
        {
            for (int repeats = 0; repeats < 10; repeats++)
            {
                for (int i = 0; i < list.Count; i++)
                {
                    int otherInd = rand.Next(0, list.Count);
                    var swap = list[i];
                    list[i] = list[otherInd];
                    list[otherInd] = swap;
                }
            }
        }
    }
}
